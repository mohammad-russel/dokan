<div class="header">
    <a href="../index.php"><img src="../logo/perfect.png" alt=""></a>
    <span class="title"><a href="#">ADMIN</a></span>
</div>
<div class="box">
    <ul>
        <a href="admin_home.php">Dashboard</a>
        <a href="manage_order.php">Orders</a>
        <a href="staffs.php">Staffs</a>
        <a href="admin_product.php">Products</a>
        <a href="admin_setday.php">Set Days</a>
        <a href="admin_categories.php">Categories</a>
        <a href="admin_signature.php">Signature</a>
        <a href="admin_other.php">Other</a>
    </ul>
</div>
<div class="footer">
    <span class="logout">
        <a href="../php/admin_logout.php">
            <ion-icon name="log-out-outline"></ion-icon>
            <span class="title">Logout</span>
        </a>

    </span>
</div>